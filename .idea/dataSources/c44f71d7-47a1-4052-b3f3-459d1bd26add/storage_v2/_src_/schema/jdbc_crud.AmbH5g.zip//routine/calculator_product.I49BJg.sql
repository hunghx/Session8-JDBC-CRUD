create
    definer = root@localhost procedure calculator_product(OUT avg_price double, OUT total_quantity int)
begin
    select avg(price) into avg_price from product;
    select sum(stock) into total_quantity from product;
end;

