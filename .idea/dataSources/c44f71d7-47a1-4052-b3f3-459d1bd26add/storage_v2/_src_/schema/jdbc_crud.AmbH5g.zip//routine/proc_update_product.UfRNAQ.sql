create
    definer = root@localhost procedure proc_update_product(IN idEdit int, IN nameUp varchar(100), IN des text,
                                                           IN priceUp double, IN stockUp int, IN imageUrl text)
begin
    Update product set name = nameUp, description = des,price =priceUp,stock=stockUp,
                       image_url = imageUrl where id = idEdit;
end;

